title: 23种设计模式之Builder设计模式
date: '2019-09-11 23:14:48'
updated: '2019-09-11 23:14:55'
tags: [java, 设计模式]
permalink: /BuilderMod
---
# 概述  
建造者模式（Builder Pattern），是创造性模式之一，Builder 模式的目的则是为了将对象的构建与展示分离。Builder 模式是一步一步创建一个复杂对象的创建型模式，它允许用户在不知道内部构建细节的情况下，可以更精细地控制对象的构造流程。  
# 本质
分离了对象子组件的单独构造（由Builder来单独负责）和装配（由Director来负责）从而构造出复杂的对象，从而实现了构造和装配的解耦，不同构造器相同装备装配也可以做出不同的对象；相同构造器不同装配顺序也可以做好受不同的对象，也就是实现了构建算法和装配算法的解耦，实现了更好的复用。

#   UML类图  

![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/%E7%B1%BB%E5%9B%BE.png)
# 角色介绍
| 名字        | 说明                                          |
| :---------- | :-------------------------------------------- |
| Builder     | 定义了产品的接口                                |
| Director    | 定义实际构造产品的类                            |
| TextBuilder | Builder接口的实现类（此处的产品指的是纯文本类）   |
| HTMLBuilder | Builder接口的实现类（此处的产品指的是HTML文本类） |
| Client      | 测试程序行为的类                                |

# Builder模式简单实现  
### Builer接口
```java  
    public interface Builder {
	public abstract void makeTitle(String title);
	public abstract void makeString(String str);
	public abstract void makeItems(String[] items);
	public abstract void close();
}
```
### Director构造类
```java  
    public class Director {
	private Builder builder;
	public Director(Builder builder){
		this.builder=builder;
	}
	/*
	 * 具体进行文档创建的方法,包含创建文档的若干步骤
	 */
	public void construct(){
		builder.makeTitle("标题");
		builder.makeString("我是正文");
		builder.makeItems(new String[]{
				"晚上好","早上好"
		});
		builder.close();
	}
}

```
### TextBuilderiy纯文本实现类  
```java  
    public class TextBulider implements Builder{
	private StringBuffer buffer=new StringBuffer();
	@Override
	public void makeTitle(String title) {
		buffer.append("*===========================*");
		buffer.append("["+title+"]");
		buffer.append("\n");
	}

	@Override
	public void makeString(String str) {
		buffer.append("-->:"+str+"\n");
		buffer.append("\n");
	}

	@Override
	public void makeItems(String[] items) {
		for(int i=0;i<items.length;i++){
			buffer.append("  ."+items[i]+"\n");
		}
		buffer.append("\n");
	}

	@Override
	public void close() {
		buffer.append("============================\n");
	}
	public String getResult(){
		return buffer.toString();
	}
}

```
### HTMLBuilder网页文本实现类  
```java  
    public class HTMLBuilder implements Builder{
	private StringBuffer buffer=new StringBuffer();
	@Override
	public void makeTitle(String title) {
		buffer.append("<html><head><title>"+title+"</title>");
	}

	@Override
	public void makeString(String str) {
		buffer.append("<p>"+str+"</p>");
	}

	@Override
	public void makeItems(String[] items) {
		buffer.append("<ul>");
		for(int i=0;i<items.length;i++){
			buffer.append("<li>"+items[i]+"</li>");
		}
		buffer.append("</ul>");
	}

	@Override
	public void close() {
		buffer.append("</body></html>");
	}
	public String getResult(){
		return buffer.toString();
	}
}
  ```
### Client测试类
 ```java  
  public class Client {
	public static void main(String[] args) {
		HTMLBuilder builder =new HTMLBuilder();
		Director director=new Director(builder);
		director.construct();
		String result=builder.getResult();
		System.out.println(result);
	}
}

  ```
