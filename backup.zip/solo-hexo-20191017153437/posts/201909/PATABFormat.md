title: PAT A+B Format
date: '2019-09-11 23:27:18'
updated: '2019-09-11 23:27:18'
tags: [算法, c++]
permalink: /HelloPat
---
# P1001 A+B Format
---  
<strong>原题</strong>  
Calculate a+b and output the sum in standard format -- that is, the digits must be separated into groups of three by commas (unless there are less than four digits).

<strong>Input Specification:</strong>
Each input file contains one test case. Each case contains a pair of integers a and b where $10^{-6}\leq a,b\leqslant 10^{6}$.The numbers are separated by a space.

<strong>Output Specification:</strong>
For each test case, you should output the sum of a and b in one line. The sum must be written in the standard format.

<strong>Sample Input:</strong>
```
-1000000 9
```
<strong>Sample Output:</strong>
```
-999,991
```
<strong>题目链接:</strong>  [https://pintia.cn/problem-sets/994805342720868352/problems/994805528788582400](https://pintia.cn/problem-sets/994805342720868352/problems/994805528788582400)

<strong>题目的中文意思:</strong>    
题目的大概意思是计算出两个数的和然后将其结果每隔三位加以逗号的形式输出出来。

<strong>代码实现:</strong>  
```C++
#include <stdio.h>
#include <iostream>
#include <stack>
using namespace std;

//用标准化的形式输出两个数之和
int main()
{
	stack<char> st;
	long int a, b,sum;
	scanf("%ld %ld", &a, &b);
	sum = a + b;
	int i = 0; //记录放入栈中的实际元素数
	if (sum == 0) printf("0\n");
	else
	{
		if (sum < 0)
		{
			printf("-");
			sum = -sum;
		}
		int i = 0;//记录实际存储的数字个数
		while (sum!=0)
		{
			st.push(sum % 10+'0');
			i++;
			if (i % 3 == 0) st.push(',');
			sum /= 10;
		}
	}
	//输出栈中的所有数据
	//处理最后一位刚好被三整除的异常
	if (!st.empty()&&st.top() == ',') st.pop();
	while (!st.empty())
	{
		printf("%c",st.top());
		st.pop();
	}
	//system("pause");
	return 0;
}
```
